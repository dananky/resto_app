<?php
$lang['outlet'] = 'আউটলেট';


/* End of file afar_lang.php */
/* Location: ./application/language/afar/afar_lang.php */
